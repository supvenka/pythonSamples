# prime numbers between 1 to 20

for number in range(2,21):
    #flag = False
    for divisor in range(2,number):
        if not number % divisor :
            #flag = True
            break

    else:
        print number, "is prime"

    # if not flag:
    #     print number, "is prime"