data = ['C', 'C++', 'Java', 100, 200]

# operations

print "No. of elements:", len(data)
print "First element:", data[0]
print "Last element:", data[-1]

# membership

if 'Python' in data:
    print "available"
else:
    print "Not available"

# iterations

for item in data:
    print "Item:", item

for idx, item in enumerate(data):
    print "Index:", idx, " Item:", item

print "Index of C++:", data.index('C++')

# add element to list - extend, append, insert

data.extend(['Python', 'Ruby'])

print data

data.append('Java')
print data

data.append(('R', 'GO'))
print data

data.insert(0, 'Java')
print data

# updation
data[0] = 'JavaScript'
print data
