import os
import datetime
#os.mkdir("demo")

#os.rmdir("demo")

print "Current working dir:", os.getcwd()

#os.chdir(r'/Users/shridevisawant/Desktop')

cwd = os.getcwd()
print os.listdir(cwd)

filename = "Oracle.txt"

fullPath = os.path.join(cwd, filename)

print "FullPath:", fullPath

if os.path.exists(fullPath):
    if os.path.isfile(fullPath):
        print "File information---"
        print "Size of file:", os.path.getsize(fullPath)
        t = os.path.getmtime(fullPath)
        humanT = datetime.datetime.fromtimestamp(t)
        print "Last modified time:", humanT


def getDetails(dirpath):
    # list of subdirectoris, list of files
    # listdir - list
    # isFile(), isDir()

    # 2 - list of files - recursively
    pass


getDetails("/home/shridevisawant")

