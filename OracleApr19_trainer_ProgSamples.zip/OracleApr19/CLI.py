import argparse

parser = argparse.ArgumentParser(description="This is a demo script.")

# optional args
parser.add_argument('-a', dest="filename", help="file to be read")
parser.add_argument('-b', dest="noOfBytes", type=int, help="No of bytes to read")
parser.add_argument('-c', default=False, help="is it dir?")

# positional args
parser.add_argument('count', help="some help", type=int)
parser.add_argument('units', help="either cms or meters")

args = parser.parse_args()

print args
print "a:", args.filename
print "b:", args.noOfBytes
print "c:", args.c

print "Count:", args.count
print "Units:", args.units
