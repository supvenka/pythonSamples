"""
This is my sample program
"""
print "Hi! Good morning"

# continuation char ''

var1 = "Hi Oracle "\
        + "Good Morning."

var2 = var1 +\
        "xyz"


print var1

# quotes

word = "Oracle's product"
sentence = "Python is a Good Programming language"
para = """line 1
line2
line 3"""

print word
print sentence
print para

# raw_input

name = raw_input("Enter your name:")

print  name, ", How are you?"

age = raw_input("Enter your age:")

print "In 2021, your age will be", int(age)+2


