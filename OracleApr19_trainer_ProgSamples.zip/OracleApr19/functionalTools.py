numberList = [1,2,3,4,5,6,7,8,9,10]

# list of even numbers

def isEven(n):
    if n%2 ==0:
        return True
    else:
        return False

# evenList =[]
# for number in numberList:
#     if isEven(number):
#         evenList.append(number)
#
# print evenList

# function - return boolean, input - one argument
evenList = filter(isEven, numberList)

# using lambda

evenList = filter(lambda x: not x%2, numberList)
print "Using lambda:", evenList

# square of numbers
numberList = [1,2,3,4,5,6,7,8,9,10]

def squareMe(n):
    #print n*n
    return n*n

# function - returning some value, single argument
squareList = map(squareMe, numberList)
print "Square of numbers:", squareList

# using lambda
squareList = map(lambda x:x*x, numberList)
print "Using lambda:", squareList

numberList = [1,2,3,4,5,6,7,8,9,10]

# cumulative sum of all numbers

def add(a,b):
    return a+b

#  functions - two arguments, returning value
cumulativeSum = reduce(add, numberList)
print "Cumulative sum=", cumulativeSum

# using lambda
cumulativeSum = reduce(lambda x,y: x+y, numberList)
print "Cumulative sum=", cumulativeSum

numberList = [12,72,938,2372,90539,2372]

def max(a,b):
    if a>b:
        return a
    else:
        return b

maxNumber = reduce(max, numberList)
print maxNumber

# python - val1 if condition else val2

maxNumber = reduce(lambda x,y: x if x>y else y, numberList)
print maxNumber