def writeToFile(data):

    try:
        fp = open("Oracle.txt")
        fp.write(data)
    except IOError as err:
        print "Either file opening or writting failed.."
        print "Exception message:", err.message
    except Exception as err: # generic exception handling
        print "Unknown error:", err.message
    else: # when no exception
        fp.close()
        print "Data written successfully"
    finally: # always executed
        print "Either exception happened or not"

    print "DONE"


def writeAgain(data):

    try:
        fp = open("Oracle.txt")
        try:
            fp.write(data)
            # except IOError as err:
            #     print "Writting failed:", err.message
            # else:
            #     print "Data written succesfully"
        finally:
            print "Inner finally"
            fp.close()

    except IOError as err:
        print "Opening failed:", err.message
    except Exception as err:
        print "Generic"
    else:
       print "Success"

writeAgain("sdfksjk")