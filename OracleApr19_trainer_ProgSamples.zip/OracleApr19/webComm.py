import requests

url = "http://google.com"

respObj = requests.get(url)


print "content:", respObj.content
print "Status Code:", respObj.status_code