#1. required arguments

def displayInfo(name):
    print name

displayInfo("Shridevi")


#2. keyword Arguments
def printInfo(name, age, gender):
    print "Name:", name
    print "Age:", age
    print "Gender:", gender

printInfo("John", 10, "M")
printInfo(age=30, name="merry", gender="F")
printInfo("Shree", gender="F", age=33)

#3. default arguments- optional arguments
# Rules- placed after required arguments, can have multiple
def calculateEMI(amount, rate=10, duration=12):
    emi= amount * rate/100/duration
    print "Amount:", amount
    print "Rate:", rate
    print "Duration:", duration
    print "EMI:", emi

calculateEMI(1000)
calculateEMI(1000, duration=24)

#4. variable length arguments
# Rules- placed after required args, can have only one,
# cannot combine with default args
def joinStr(delimiter, *args):
    print "No of arguments:", len(args)
    return delimiter.join(args)

print joinStr('-', "a", "b","c")
print joinStr("*","Oracle", "GE")

def add(*args):
    result =0
    for i in args:
        result += i

    print result
    return result


print "10+20=", add(10,20)
print "10+20+30=", add(10,20,30)

x= add

x(70,79)