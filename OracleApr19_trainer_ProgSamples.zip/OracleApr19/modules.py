#import fileOp
#from fileOp import readFromFile as myread

import fileOp
#import myPackage.test1

#fileOp.readFromFile()

#from myPackage import test1
from myPackage import *
print test1.add(10,20)