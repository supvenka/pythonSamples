from Tkinter import *
import subprocess

root = Tk()
root.title("Oracle")
root.geometry("600x400")

fr = Frame(root, width=400, height=300, bg='yellow',
           relief=RAISED, borderwidth=15)
fr.pack()
fr.pack_propagate(False)

lable = Label(fr, text="Welcome to Oracle")
lable.pack()

userid = Entry(fr)
userid.pack()

def buttonClick():
    print 'Button clicked..'
    ipAddr = userid.get()

    pingOutput = subprocess.check_output(['ping','-c3', ipAddr])

    #textToDisplay = "Hi "+ useridT + ", Thank you for using our software."
    msg = Message(fr, text=pingOutput)
    msg.pack()

b1 = Button(fr, text="Continue", command=buttonClick)
b1.pack()

root.mainloop()