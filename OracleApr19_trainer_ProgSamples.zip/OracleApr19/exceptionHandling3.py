def add(a,b):

    if type(a) is int and type(b) is int:
        pass
    elif type(a) is str and type(b) is str:
        pass
    else:
        raise TypeError("Either int or str")
    c = a+b
    print "Result=", c

try:
    add(10,20)
    add(10, 'xyz')
except Exception as err:
    print err.message


# user defined exception

class HTTPError(Exception):

    def __init__(self, msg, code):
        self.message = msg
        self.code = code


def doHTTPComm():

    # code for communicating remote server

    response = 500
    if response != 200:
        if response == 404:
            raise HTTPError("File Not Found", response)
        elif response == 500:
            raise HTTPError("Server error", response)
        else:
            raise HTTPError("Unknown erro", response)


try:
    doHTTPComm()
except HTTPError as err:
    print "Message:", err.message
    print "Code:", err.code