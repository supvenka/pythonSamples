import socket

# create, bind, listen, accept, send/recv, close

listenS = socket.socket() # TCP/IP socket

hostname = 'localhost'
port = 5500

listenS.bind((hostname, port))

listenS.listen(1)

print "Server started listening on ", port

(clientS, clientAddr)=listenS.accept()

print "Received connection from ", clientAddr

clientS.send("Hello Client!")

data = clientS.recv(1024)

while data:
    print "Received from client:", data
    msg = raw_input("Enter message or 'EXIT':")
    if msg != 'EXIT':
        clientS.send(msg)
    else:
        break

    data = clientS.recv(1024)

clientS.close()
print "Client connection closed"
listenS.close()
print "Server shutdown"


