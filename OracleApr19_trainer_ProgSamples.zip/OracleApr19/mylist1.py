data = ['Java', 'C', 'C++', 'Java', 'Python']

# removal- del, remove(), pop()

print data

del data[1]

print data

# javaOccr = data.count('Java')
#
# for _ in range(javaOccr):
#
#     data.remove('Java')

while 'Java' in data:
    data.remove('Java')

print data

if 'Ruby' in data:
    data.remove('Ruby')

data = ['Java', 'C', 'C++', 'Java', 'Python']

removedItem = data.pop()
print data
print "Removed:", removedItem

removedItem = data.pop(0)
print data
print "Removed:", removedItem

mylist = list('Oracle Corporation India')
print mylist

mylist.reverse()
print mylist

revesedStr = ''.join(mylist)

data = ['Java', 'C', 'C++', 'Java', 'Python']

# slicing

print data[1:3]

print "first 2 elements:", data[:2]

print "last 2 elements:", data[-2:]

