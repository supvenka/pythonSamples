import subprocess
import platform

filename = "Oracle.txt"

osType = platform.system()

# if osType=='Darwin':
#     subprocess.call(['open', filename])
# elif osType =='Windows':
#     subprocess.call(['start', filename], shell=True)


subprocess.call(['python', 'CLI.py', '-a myfile', '10', 'cms'])

#subprocess.call(['javac', 'temp.java'])