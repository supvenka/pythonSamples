adharDB = {}

# input from user -
# adharNo, name, mobile, city

# Enter for 3 records
# key- adharNo
# value - {'name': , 'mobile': , 'city: }

for _ in range(3):
    name = raw_input("Enter Name:")
    mobile = raw_input("Enter mobile:")
    city= raw_input("Enter City:")
    while True:
        adharNo = raw_input("Enter Adhar No:")
        if adharNo.isdigit() and len(adharNo)==12:
            break



    adharDB[adharNo] = {'name': name, 'phone':mobile, 'city':city}

print "*****\n"
print adharDB