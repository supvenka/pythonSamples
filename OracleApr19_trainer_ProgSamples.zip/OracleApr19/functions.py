def add(a,b):
    "simple addition: a,b :both as int or str"

    if type(a) is int and type(b) is int:
        pass
    elif type(a) is str and type(b) is str:
        pass
    else:
        print "Invalid type"
        return

    result = a+b
    return result



# function overloading not available
def add(a,b,c):
    "Another add"
    return a+b+c

#print "10+20=", add(10,20)

print "10+20+30=", add(10,20,30)

# function - factorial of number
# n! = n * (n-1)!
# 1!= 1

def factorial(n):
    "Calculates factorial of number in recursive way"
    if type(n) is int:

        if n == 1:
            return 1
        else:
            return n * factorial(n-1)



print "2!=", factorial(2)
print "5!=", factorial(5)

