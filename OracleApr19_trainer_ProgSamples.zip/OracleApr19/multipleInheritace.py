class Parent1(object):

    def displayInfo(self):
        print "Parent 1 "

class Parent2(object):

    def displayInfo(self):
        print "Parent 2"

# MRO- Method resolution Order
class Child(Parent2, Parent1):

    def displayInfo(self):
        super(Child, self).displayInfo()


c = Child()
c.displayInfo()