personName = "John"
address = "Bangalore"
pincode = 560011

# formatting using % - interpolation operator

line = "%s resides at %s with pincode %d" % \
       (personName, address, pincode)

print line

# formatting using format()

line = "{} resides at {} with pincode {}".format(personName,
                                                 address,pincode)

print "Using format - ", line

line = "{0} resides at {1} with pincode {2} and {0} is Oracle emp".format(personName,
                                                 address,pincode)

print line

for i in range(11):
    print "%03d" % i

latt = 12.89892344
longitude = 77.343253

print "Lat = %.2f \nLongitude= %.2f " % (latt, longitude)