while True:
    data = raw_input("Enter number:")

    if data.isdigit():
        print 'Valid ', data
        number = int(data)
        break
    else:
        print 'Invalid input'

