import socket

# create, connect, send/recv, close

mySock = socket.socket()

serverIP = "localhost"
serverPort = 5500

mySock.connect((serverIP, serverPort))

print "Connection established..."

data = mySock.recv(1024)

while data:
    print "Received from server:", data
    msg = raw_input("Enter message or 'EXIT':")
    if msg != 'EXIT':
        mySock.send(msg)
    else:
        break
    data = mySock.recv(1024)

mySock.close()
print "Closed connection"