import re

data = """cat Mat bat map that mapping mammmi
asd mat sjdfs"""

pattern = r'm\w\w'

# option1 - compile(), search()

regexObj = re.compile(pattern, re.IGNORECASE)
matchObj = regexObj.search(data)

if matchObj:
    print "First Occurance:", matchObj.group()
else:
    print "No match found"

# option 2 - re.search()

matchObj = re.search(pattern, data, re.IGNORECASE)
if matchObj:
    print "First Occurance:", matchObj.group()
else:
    print "No match found"

# match() - matching at the begining

matchObj = re.match(pattern, data)
if matchObj:
    print "String starts with m"
else:
    print "String doesnt start with m"

# findall() - all matches

listOfMatches = re.findall(pattern, data)
print "All matches:", listOfMatches

# split()

splitted = re.split(pattern, data,flags=re.IGNORECASE)
print "Splitted:", splitted

# sub() - replacement

replaced = re.sub(pattern, "---", data)
print "Replaced:", replaced