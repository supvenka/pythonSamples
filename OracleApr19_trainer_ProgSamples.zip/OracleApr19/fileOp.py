def writeToFile(data):

    fp = open("Oracle.txt", "w")

    fp.write(data)
    fp.write("\n---end---")
    fp.close()
    print "Data written.."

def readFromFile():

    fp = open("Oracle.txt") # default mode- rt


    data = fp.read(10)
    print "First 10 chars:", data
    print "File pointer position:", fp.tell()
    data = fp.read()
    print "Remaining chars:", data
    fp.seek(0, 0)
    # offset, where - 0-begining, 1- current position, 2- end

    print "File position:", fp.tell()
    data = fp.read()
    print "All data:", data
    fp.seek(-10,2)
    print "file position: ", fp.tell()

    data = fp.read()
    print "Last 10 chars:", data

    fp.close()



print __name__

if __name__ == '__main__':
    writeToFile("Good Morning!Python is a functional programming language")
    readFromFile()
