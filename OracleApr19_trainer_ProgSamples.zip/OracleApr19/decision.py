number = int(raw_input("Enter any number:"))

print type(number)

if number>0 :
    print number, "is positive"
elif number == 0:
    print number, 'is Zero'
else:
    print number, 'is negative'

if number % 2 == 0:
    print number, "is Even"
else:
    print number, 'is Odd'

# nested if
if number > 35:
    print "PASS"
    if number>75:
        print "Distinction"
    elif number>65:
        print "First class"
    elif number>55:
        print "Second class"
    else:
        print "Third class"
else:
    print "Failed"

# logical operators- and , or, not

if number>0 and not number%2:
    print "Even Positive number"
