logs = """ This is error log #1
This is error log #2
This is debug log #3
This is error log #4
This is debug log #5
This is error log #6 err
This is error log #100 critical"""

# no of logs
# no of error logs with message, id
# no of debug logs


logsCount = logs.count('log')
errCount = logs.count('error')
debugCount = logs.count('debug')


print logsCount
print errCount
print debugCount

lines = logs.splitlines()

for line in lines:
    pos = line.find('error')
    if pos != -1:
        #error log
        print "Log Message:", line
        hashPos = line.find('#')
        spacePos = line.find(' ', hashPos)
        if spacePos == -1:
            id = line[hashPos+1:]
        else:
            id = line[hashPos+1:spacePos]
        print "ID:", id
