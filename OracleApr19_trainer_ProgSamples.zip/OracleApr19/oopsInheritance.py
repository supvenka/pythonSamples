class Employee(object):
    "Base class for all employees"

    empCount = 0
    bonus = 100


    def __init__(self, fName, lName, salary):
        self.firstName = fName
        self.lastName = lName
        self.salary = salary

        Employee.empCount += 1
        print "Init of Employee done"

    def displayInfo(self):

        print "Name:", self.firstName+" " +self.lastName
        print "Salary:", self.salary

    def applyBonus(self):
        self.salary += self.bonus

## end of Employee class

class Developer(Employee):

    bonus = 200

    def __init__(self, fName, lName, salary, skills):

        super(Developer, self).__init__(fName, lName, salary)
        self.skills = skills
        print "Init of Developer done"

    def displayInfo(self):
        print "-----Developer-----"
        super(Developer, self).displayInfo()
        print "Skills:", self.skills

## end of Developer class

class Tester(Employee):

    bonus = 150

    def __init__(self, fName,lName,salary, tools):
        super(Tester, self).__init__(fName, lName, salary)
        self.tools = tools

    def displayInfo(self):
        print '-----Tester ---'
        super(Tester, self).displayInfo()
        print "Testing Tools:", self.tools

## end of Tester class

emp1 = Developer("John", "Smith", 1000, "Python")
emp1.applyBonus()
emp1.displayInfo()

emp2 = Employee("Merry", "Rose", 1000)
emp2.applyBonus()
emp2.displayInfo()

emp3 = Tester("Mike", "Tyson", 1000, "Selenium")
emp3.applyBonus()
emp3.displayInfo()

listOfEmp = [emp1, emp2, emp3]



# polymorphism - method overriding
for emp in listOfEmp:
    emp.displayInfo()