total=0 # global one
counter =0

def sum(a,b):

    global total, counter

    total = a+b
    counter += 1
    print "Inside function, total=", total

sum(10,20)
print "Outside function, total=", total

print "No of times sum() called:", counter

## function taking function as argument

def doOperations(operation, a,b):
   print operation(a,b)

doOperations(sum, 1,2)

def subtract(a,b):
    print a-b

mySubtract = subtract

mySubtract(20,40)

doOperations(subtract, 10, 5)

## lambda expression

add = lambda x,y:x+y
print add(20,30)

## cube of number using lambda

cube = lambda x: x ** 3
print cube(4)

joinStr = lambda *t: "-".join(t)

print joinStr("Hi","Hello","xyz")

doOperations(lambda x,y:x-y, 40,20)
