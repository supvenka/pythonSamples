import math

x = 10
y = 3.0
z=20

print "x/y =", x/y
print "x//y =", x//y

print "x%y=", x % y

divOp = divmod(x,y)

print type(divOp)
print "Division:", divOp[0]

print "23 to power of 12= ", pow(23,12)
print "9 ** 3 = ", 9 ** 3

print "square root of 127:", math.sqrt(127)
