str1 = "Hi! Good! Morning! How are you?"

print "Length of string: ", len(str1)
print "only alphanumeric chars?:", str1.isalnum()
print "only digits?:", str1.isdigit()
print "all chars in lower chase?", str1.islower()

print "no of occurances of '!':", str1.count('!')

print "First occurance at position:", str1.find('!')

print "Last occurance at position:", str1.rfind('!')

startIndex = 0
noOfOccurs = str1.count('!')
for i in range(noOfOccurs):
    index = str1.find('!', startIndex)
    print "%d Ocurrance at %d" % (i, index)
    startIndex = index+1


# split

splits = str1.split('!')

print "Splitted str:", splits

# replace

replacedStrings = str1.replace('!', '*')

print replacedStrings

# upper case string

print "Upper String:", str1.upper()

# string traversing

print "first char:", str1[0]
print "Last char:", str1[-1]
print "chars between 5 and 10:", str1[5:11]
print "chars from 5 index:", str1[5:]
print "first 10 chars:", str1[:11]

userid = "admin"

print userid.ljust(10, '-')
print userid.rjust(10, '-')
print userid.center(10, '-')

print userid.zfill(10)