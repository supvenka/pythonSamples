numberList = [1,2,3,4,5,6,7,8,9,10]

# square of even numbers

# list comprehension
# [operation for ]
sqrOfEven = [x*x for x in numberList if not x%2]
print sqrOfEven

# cube of numbers

cube = [x ** 3 for x in numberList]
print cube

pinCodeList = ['560011', '123', '560068', '234']
# valid pincodes

validPin = [x for x in pinCodeList if x.isdigit() and len(x)==6]
print validPin

pincodes = [x if len(x)==6 else x.zfill(6) for x in pinCodeList]
print pincodes

myData = ['abc', 'xyz', 'a123', '09ab', 'pqr']

# valid names- only alphabets
validStrs = [x for x in myData if x.isalpha()]

print validStrs

newStrs = [x if x.isalpha() else 'NA' for x in myData]
print newStrs