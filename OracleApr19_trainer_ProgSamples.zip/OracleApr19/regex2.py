import re

str1 = "john: 1234567890, Merry:098, robert:234, Ruby:11100"

# get all phone numbers

print "All phone numbers:", re.findall(r'\d+', str1)

# get all contact names

print "All names:", re.findall(r'[a-zA-Z]+', str1)

# get valid phone numbers - 10 digits

print "All valid numbers:", re.findall(r'\b\d{10}\b', str1)

# all names starting with 'r'

print "All names:", re.findall(r'\b[rR][a-zA-Z]+', str1)