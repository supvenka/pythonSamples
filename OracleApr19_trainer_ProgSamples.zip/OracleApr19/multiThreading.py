import threading

counter = 0

# Race Condition - shared resource

def incrementCounter(lockObj):
    global counter

    for _ in range(100000):
        lockObj.acquire() # put lock
        counter +=1
        lockObj.release() # unlock

myLock = threading.Lock()

t1 = threading.Thread(target=incrementCounter, args=(myLock,))
t2 = threading.Thread(target=incrementCounter, args=(myLock,))

t1.start()
t2.start()

t1.join()
t2.join()

print "Counter=", counter