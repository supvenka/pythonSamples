
# for loop - iterate over sequence

for ch in 'Oracle':
    print "Alphabet:", ch

osList = ["Symbian", "Android", "iOs"]

for osName in osList:
    print "OS:", osName

print "SQuare of numbers from 0 to 5"

for i in range(6):
    print "Square of ",i , "=", i*i

print "Even numbers from 0 to 10:"

for i in range(0,11,2):

    print i

print "numbers from 0 to 5 in reverse order"

for i in range(5,-1,-1):
    print i

# while loop - based on condition

counter = 0
while counter<3:
    print "Counter:", counter
    counter +=1

# nested loop

print "Tables of 21 to 25"

for number in range(21,26):
    print "**** Table of ", number
    for i in range(1,11):
        print number*i

