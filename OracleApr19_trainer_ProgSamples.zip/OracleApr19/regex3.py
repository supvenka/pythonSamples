import re

str1 = "john 1234 12/12/2000, merry 893 01-02-1994, robert 2333 1/1/98"

# DOB

print "DOB:", re.findall(r'\d+[/-]\d{1,2}[/-]\d{2,4}', str1)

# YOB

print "YOB:", re.findall(r'\d+[/-]\d{1,2}[/-](\d{2,4})', str1)

str2 = "12.23.10.1 127.0.0.1 23.34 100.1.11 "

# valid ips

print "Valid ips:", re.findall(r'\b\d+\.\d+\.\d+\.\d+', str2)
#print "Valid ips:", re.findall(r'\b(?:\d+\.){3}\d+', str2)

str3 = "test@oracle1.com, abc@test.com, xyz@gmail.com"

# domain names
print "Domains:", re.findall(r'@(\w+\.\w+)', str3)

logs = """ Error log #1
debug log #10 msg
error log #100 err"""

# log ids

ids = re.findall(r'#(\d+)', logs)
print ids

str4 = "ant bat orange umbrella mango"

# words starting with vowels
print "Words starting with vowels:", re.findall(r'\b[aeiou]\w+', str4)

# remove words starting with vowels
print re.sub(r'\b[aeiou][a-zA-Z]+', '', str4)