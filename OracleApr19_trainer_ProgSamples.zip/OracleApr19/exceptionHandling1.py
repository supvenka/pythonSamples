try:
    x = float(raw_input("Input number:"))
    inverse = 1/x
except ValueError:
    print "Please enter only number"
except ZeroDivisionError:
    print "Please enter only non-zero number"
except Exception as err:
    print "Unknown error:", err.message
else:# no exception
    print "Inverse:", inverse
finally:
    print "DONE"