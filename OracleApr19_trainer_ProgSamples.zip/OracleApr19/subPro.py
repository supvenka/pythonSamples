import subprocess
import platform

ret = subprocess.call(['date', '\t'], shell=True)

ret = subprocess.call('date \t', shell=True)

print "Status code:", ret

today = subprocess.check_output(['date', '\t'], shell=True)

print "Today's date:", today

print "OS:", platform.system()

osType = platform.system()

if osType == 'Darwin': #MAC
    #subprocess.call(['ls', '-l'])

    proc = subprocess.Popen(['ls', '-l', 'x'], stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, shell=True)
    stdOp, stdErr = proc.communicate()
    print "Output:", stdOp
    print "Error:", stdErr

elif osType == 'Windows': #windows
    proc = subprocess.Popen(['dir'], stdout=subprocess.PIPE,
                            shell=True,stderr=subprocess.PIPE)
    stdOp, stdErr = proc.communicate()
    print "Output:", stdOp
    print "Error:", stdErr
else: # Linux
    pass
