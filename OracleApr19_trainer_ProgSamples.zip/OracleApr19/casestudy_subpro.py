import platform
import subprocess

type = platform.system()

def killChrome():
    if type == 'Darwin':


        subprocess.call(['killall', 'Google Chrome'])


    elif type == 'Windows':
        subprocess.call(['taskkill', '/IM', 'chrome.exe', '/F'])

killChrome()