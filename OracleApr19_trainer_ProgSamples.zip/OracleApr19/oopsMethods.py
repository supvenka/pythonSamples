class MathUtils(object):

    @staticmethod
    def add(a,b):
        return a+b

    @staticmethod
    def subtract(a,b):
        return a-b


print MathUtils.add(10,20)

print MathUtils.subtract(20,10)