# break, continue, pass

for ch in 'Oracle':
    if ch == 'a':
        #break
        #continue
        pass

    print "Letter:", ch

print "DONE"

for i in range(3):
    print i
    if i==2:
        break
else:
    print "Loop is done"

counter = 0
while counter<3:
    print "Counter=", counter
    counter += 1
else:
    print "counter is more than 3"

