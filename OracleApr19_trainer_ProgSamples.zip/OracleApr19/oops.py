class Employee(object):
    "Simple Employee class"

    # class variable- shared across all objects
    empCount = 0

    # called when object is created
    def __init__(self, fName, lName, salary):
        self.firstName = fName
        self.lastName = lName
        self.__salary = salary

        #self.fullName = fName + " " + lName
        Employee.empCount += 1
        # instance variables - firstName, lastName, salary, fullName
        print 'Init is done'

    @property
    def fullName(self):
        return self.firstName + " " + self.lastName

    # def displayCount(self):
    #     print "Employee Count=", Employee.empCount

    @classmethod
    def displayCount(cls):
        print "Employee Count=", cls.empCount

    def displayInfo(self):
        print "Full Name:", self.fullName
        print "Salary:", self.__salary

    def __applyBonus(self):
        if hasattr(self, 'bonus'):

            pass
        else:
            print "No Bonus:"
            #self.bonus = 10
            setattr(self, 'bonus', 10)

        self.__salary += self.bonus




## end of class definition

# create objects
emp1 = Employee("John", "Smith", 1000)
emp2 = Employee("Merry", "Rose", 2000)

#Employee.displayCount()

Employee.displayCount()


#
# #emp1.displayInfo()
#
# emp1.lastName = "Laidlaw"
#
# #emp1.displayInfo()
#
# print "Fullname:", emp1.fullName
#
# emp1.displayInfo()

#print "Salary:", emp1.__salary









