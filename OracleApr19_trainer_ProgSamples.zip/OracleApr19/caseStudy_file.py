# list of IP address and list of port numbers

fp = open("ipAddress.txt")

lines = fp.readlines()

listOfIp =[]
listOfPort=[]

for line in lines:
    splits = line.split()
    ip = splits[0]
    if ip.count('.') == 3:
        listOfIp.append(ip)
    listOfPort.append(splits[1])

print "IPs:", listOfIp
print "Ports:", listOfPort

fp.close()

listOfIp =[]
listOfPort=[]

with open("ipAddress.txt") as fp:

    line = fp.readline()
    while line:
        splits = line.split()
        listOfIp.append(splits[0])
        listOfPort.append(splits[1])
        line = fp.readline()

print "IPs:", listOfIp
print "Ports:", listOfPort