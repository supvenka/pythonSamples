contacts = {'john': 123}

contacts['merry'] = 987

print contacts

contacts['john'] = 345
print contacts

print "phone number of merry:", contacts['merry']
#print "Ruby's number:", contacts['Ruby']
print "Ruby's number:", contacts.get('Ruby', 100)

if 'Ruby' in contacts:
    print "Ruby's number:", contacts['Ruby']
else:
    print "No contact info of Ruby"

officeContacts={'Robert':787, 'john': 111, 'Mike':333}

contacts.update(officeContacts)

print contacts

friends = ['abc', 'xyz']

friendsContacts = dict.fromkeys(friends, 100)

print friendsContacts

mydict = {'john': [100, 111, 222]}

mydict['john'].append(987)

print mydict['john']

# iteration

officeContacts={'Robert':787, 'john': 111, 'Mike':333}

print "Total contacts:", len(officeContacts)
print officeContacts

print "Contact names:"
for k in officeContacts.keys():
    print k

print "phone numbers:"

for v in officeContacts.values():
    print v

for k,v in officeContacts.items():
    print "Phone number of ", k, ":", v

officeContacts['john'] = {'mobile': 123, 'landline':80}

print 'landline of john:', officeContacts['john']['landline']
print officeContacts

removed = officeContacts.pop('Robert')
print officeContacts
print "Removed:", removed

officeContacts.clear()
print officeContacts