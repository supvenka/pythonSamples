import subprocess
import platform


osType = platform.system()

if osType == 'Darwin': #MAC
    #subprocess.call(['ls', '-l'])

    proc = subprocess.Popen(['ls', '-l'], stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, shell=True)

    matchProc = subprocess.Popen(['grep', '.txt'], stdin=proc.stdout,
                                 stdout=subprocess.PIPE)

    output = matchProc.communicate()[0]
    print "Output:", output

elif osType == 'Windows': #windows
    proc = subprocess.Popen(['dir'], stdout=subprocess.PIPE,
                            shell=True,stderr=subprocess.PIPE)

    matchProc = subprocess.Popen(['findstr', '.txt'], stdin=proc.stdout,
                                 stdout=subprocess.PIPE, shell=True)

    output = matchProc.communicate()[0]
    print "Output:", output

else: # Linux
    pass
