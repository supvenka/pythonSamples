data = (1,'John','Bangalore')

print data

for item in data:
    print "Item:", item

print 'First element:', data[0]

mylist = list(data)
mylist.append(560011)
data = tuple(mylist)

print data