import sys
import os

print "No of arguments:", len(sys.argv)
print "Arguments:", sys.argv

# read file and display content

if len(sys.argv) != 3:
    print "Please provide exactly one filename and no of bytes to read.."
    exit()
else:
    filename = sys.argv[1]
    noOfBytes = int(sys.argv[2])

if os.path.exists(filename) and os.path.isfile(filename):
    fp = open(filename)
    data = fp.read(noOfBytes)
    print "File Contents ----"
    print data
    fp.close()
else:
    print "File doesn't exist."
