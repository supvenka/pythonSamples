import requests

pincode = raw_input("Enter pincode:")

url = "http://api.geonames.org/postalCodeSearchJSON?postalcode=" + \
      pincode + "&maxRows=10&username=shree"

respObj = requests.get(url)

jsonArray = respObj.json()['postalCodes']

for entry in jsonArray:

    print "Area:", entry['placeName']